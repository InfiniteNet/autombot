<?php
$host = 'localhost';
$db = 'u929696492_teste';
$user = 'u929696492_teste';
$pass = 'Gvt@946894334';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database $db :" . $e->getMessage());
}
?>