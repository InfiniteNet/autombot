<?php
// Inicie o buffer de saída
ob_start();

// Inclua o script que você deseja executar
include '../script/update_schedules.php';

// Limpe o buffer e desative a saída
ob_end_clean();
?>
<?php
// Inicie o buffer de saída
ob_start();

// Inclua o script que você deseja executar
include '../script/update_disponibilidade.php';

// Limpe o buffer e desative a saída
ob_end_clean();
?>
<?php
// Inicie o buffer de saída
ob_start();

// Inclua o script que você deseja executar
include '../script/buscar_json.php';

// Limpe o buffer e desative a saída
ob_end_clean();
?>
<?php
// Inicie o buffer de saída
ob_start();

// Inclua o script que você deseja executar
include '../script/historico.php';

// Limpe o buffer e desative a saída
ob_end_clean();
?>

<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../public/check.php';
verificarDominioToken();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}


$user_id = $_SESSION['user_id'];
$user_code = $_SESSION['user_code'];
$user_role = $_SESSION['user_role'] ?? '';

// Definir o timezone para o horário de Brasília
date_default_timezone_set('America/Sao_Paulo');

// Buscar dados do usuário
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Função para buscar o domínio na tabela config
function buscarDominio($pdo) {
    $stmt = $pdo->prepare("SELECT dominio FROM config WHERE id = 1"); // Supondo que a linha com id=1 tenha o domínio desejado
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['dominio'] ?? null;
}

// Busca o domínio no banco de dados
$dominio = buscarDominio($pdo);

// Verifica se o domínio foi encontrado
if ($dominio) {
    // Gerar o link direto para o agendamento
    $direct_link = "https://$dominio/autombot/public/agendamento.php?user_code=" . urlencode($user_code);
} else {
    $direct_link = null; // Caso o domínio não seja encontrado
}

// Caminho do arquivo JSON do usuário
$directory = '../d_user';
$json_file_path = "$directory/agendamentos_{$user_code}.json";

// Variáveis para armazenar o próximo atendimento
$next_appointment = null;
$next_procedure = null;
$next_client_name = null;
$current_time = date('Y-m-d H:i:s');

// Verificar se o arquivo JSON existe
if (file_exists($json_file_path)) {
    $json_data = json_decode(file_get_contents($json_file_path), true);

    if ($json_data && json_last_error() === JSON_ERROR_NONE) {
        // Percorrer o JSON para encontrar o próximo atendimento
        foreach ($json_data as $dia => $meses) {
            foreach ($meses as $mes => $anos) {
                foreach ($anos as $ano => $agendamentos) {
                    foreach ($agendamentos as $agendamento) {
                        $data_agendamento = "$ano-$mes-$dia " . $agendamento['start_time'];
                        if ($data_agendamento > $current_time) {
                            if (is_null($next_appointment) || $data_agendamento < $next_appointment) {
                                $next_appointment = $data_agendamento;
                                $next_procedure = $agendamento['procedimento'];
                                $next_client_name = $agendamento['nome'];
                            }
                        }
                    }
                }
            }
        }
    }
}

// Contagens de agendamentos do dia e do mês
$appointments_today = 0;
$appointments_month = 0;
$saldo_dia = 0;
$saldo_mes = 0;

if (isset($json_data) && json_last_error() === JSON_ERROR_NONE) {
    foreach ($json_data as $dia => $meses) {
        foreach ($meses as $mes => $anos) {
            foreach ($anos as $ano => $agendamentos) {
                foreach ($agendamentos as $agendamento) {
                    $data_agendamento = "$ano-$mes-$dia";
                    $start_time = $agendamento['start_time'];
                    $data_hora_agendamento = "$data_agendamento $start_time";

                    // Contar agendamentos do dia
                    if ($data_agendamento == date('Y-m-d')) {
                        $appointments_today++;
                        if (isset($agendamento['procedure_price'])) {
                            $saldo_dia += (float) $agendamento['procedure_price'];
                        }
                    }

                    // Contar agendamentos do mês
                    if (date('Y-m', strtotime($data_agendamento)) == date('Y-m')) {
                        $appointments_month++;
                        if (isset($agendamento['procedure_price'])) {
                            $saldo_mes += (float) $agendamento['procedure_price'];
                        }
                    }
                }
            }
        }
    }
}
?>
<?php if ($_SESSION['user_role'] === 'admin'): ?>
    <a href="update_from_github.php" class="menu-link">Buscar Atualização</a>
<?php endif; ?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Autombot</title>
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-image: url('/autombot/public/images/light-theme-bg.jpg');
            background-size: cover;
            background-position: center;
        }
        
        .direct-link {
            margin-top: 20px;
            padding: 10px;
            background-color: rgba(34, 34, 34, 0.8);
            border: 1px solid #555;
            border-radius: 5px;
            word-wrap: break-word;
            color: #ffffff;
        }

        .direct-link a {
            color: #ff4081;
            text-decoration: none;
        }
        
        .direct-link a:hover {
            text-decoration: underline;
        }

        .container {
            width: 90%;
            max-width: 1200px; /* Aumentei o max-width para caber os cards na mesma linha */
            margin: 0 auto;
        }

        .profile-pic {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #ff4081;
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
        }

        .cards-wrapper {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between; /* Para espaçar os cards */
        }

        .card {
            background-color: rgba(34, 34, 34, 0.8);
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            margin-bottom: 20px;
            width: 32%; /* Para três cards por linha */
            box-sizing: border-box;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        .card h2 {
            margin: 0 0 10px;
            font-size: 18px;
            color: #ff4081;
        }

        .card p {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .container {
                max-width: 90%;
            }

            .profile-pic {
                width: 50px;
                height: 50px;
            }

            .card {
                width: 100%; /* Cards ocupam 100% da largura no mobile */
            }

            .card h2 {
                font-size: 16px;
            }

            .card p {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="<?php echo htmlspecialchars($user['profile_pic']); ?>" alt="Profile Picture" class="profile-pic" onclick="window.location.href='account_settings.php'">
        
        <div class="cards-wrapper">
            <div class="card">
                <h3>Próximo Atendimento</h3>
                <p><?php echo $next_appointment ? date('d/m/Y H:i', strtotime($next_appointment)) : 'Nenhum'; ?></p>
                <p><?php echo $next_client_name ?? ''; ?></p>
            </div>
            <div class="card">
                <h3>Seu Próximo Procedimento</h3>
                <p><?php echo $next_procedure ? $next_procedure : 'Nenhum procedimento agendado'; ?></p>
            </div>
            <div class="card">
                <h3>Agendamentos de Hoje</h3>
                <p><?php echo $appointments_today; ?></p>
            </div>
            <div class="card">
                <h3>Agendamentos do Mês</h3>
                <p><?php echo $appointments_month; ?></p>
            </div>
            <div class="card">
                <h3>Saldo do Dia</h3>
                <p>R$ <?php echo number_format($saldo_dia, 2, ',', '.'); ?></p>
            </div>
            <div class="card">
                <h3>Saldo do Mês</h3>
                <p>R$ <?php echo number_format($saldo_mes, 2, ',', '.'); ?></p>
            </div>
        </div>
        
        <!-- Link direto -->
        <div class="direct-link">
            <p>Acesse seu link de agendamento:</p>
            <?php if ($direct_link): ?>
                <a href="<?php echo htmlspecialchars($direct_link); ?>"><?php echo htmlspecialchars($direct_link); ?></a>
            <?php else: ?>
                <p>Domínio não encontrado. Não foi possível gerar o link de agendamento.</p>
            <?php endif; ?>
        </div>
    </div>

    <?php include 'menu.php'; ?>
</body>
</html>
